<?php

namespace cform;



\Phar::mapPhar('cform');

spl_autoload_register(function ($class) {
    if (substr($class, 0, strlen(__NAMESPACE__)) != __NAMESPACE__)
        return;
    $path =  "phar://cform/src/" . str_replace("\\", "/", substr($class, strlen(__NAMESPACE__))) . ".php";
    require_once($path);
});


__HALT_COMPILER(); ?>
Z                    autoload.php  �@V  �qg{�      	   README.md�  �@V�  �|��         src/CFormSimpleRenderer.php[  �@V[  ����         src/CFormElement.phpA  �@VA  !rAs�         src/CForm.php�  �@V�  �A��         src/CFormRenderer.php�  �@V�  ��G�         src/CFormBootstrapRenderer.php�  �@V�  �KY��      <?php

    spl_autoload_register(function ($className) {
        $className = str_replace("\\", "/", $className);
        $fileName = __DIR__ . "/src/{$className}.php";
        if (file_exists($fileName)) {
            require( $fileName );
        }
    });
# CFORM: HTML Form printing

Printing HTML Forms in various stylesets.

## Programmatisches Beispiel

```
$form = new CForm(new CFormBootstrapRenderer());

$form->setAction("#")->setMethod("post")
     ->addInput()
          ->setLabel("Name")
          ->setName("input")
          ->setId("1234")
          ->setType("text")
          ->setValue("Insert Name")
     ->addSelect()
          ->setLabel("Age")
          ->setName("select")
          ->setId("abcd")
          ->addOption("young","21-35")
          ->addOptionSelected("middle","36-55")
          ->addOption("old","59-80")
     ->addButton([],"Display")
          ->setName("btn")
          ->setType("submit")
->out();
```

## Beispiel: Laden aus Datei

```
$form = new CForm(new CFormBootstrapRenderer());
$form->loadFromFile("form.inc.php")->out();
```

### Beispieldatei 'form.inc.php'
```
return [
        ["input", "type" => "text", "id" => "1234", "@label" => "Name", "value" => "Insert Name"],

        ["select", "id" => "abcd", "@label" => "Age", "value" => "middle", "options" => [
                "young" => "21-35",
                "middle" => "36-55",
                "old" => "56-80"]
        ],

        ["button", "name" => "btn", "type" => "submit", "displayValue" => "Display"]
];
```

## Beispiel: Formular mit Teilausgaben

```
<form action="#" method="post">
<?php
    $form = new CForm(new CFormSimpleRenderer());
    $form->addInput(["name" => "input", "id" => "1234", "type" => "text", "value" => "Insert Name"])
         ->setLabel("Name")->addDiscription("Dies ist ein Test")
         ->outPart();
    $form->addSelect(["@label" => "Age", "name" => "select", "id" => "abcd", "options" => ["young" => "21-35", "middle" => "36-55", "old" => "59-80"]])
         ->setValue("middle")
         ->addHTMLCode("<br /><br /><br /><h1>Code between...</h1>")
         ->addButton(["id" => "button", "name" => "btn", "type" => "submit"], "Display")
         ->outPart(["button"]) ?>
</form>
```
Die Methode 'outPart()' gibt alle erstellten Form-Elemente ohne die umgebenden Form-Tags aus, diese müssen manuell 
geschrieben werden. Anschließend wird die Liste der erstellten Elemente zurückgesetzt.

## Available Renderers

| Framework   | ClassName                | Example Output |
|-------------|--------------------------|----------------|
| Bootstrap   | `CFormBootstrapRenderer` |                |
| Plain Table | `CFormTableRenderer`     |                |
|             |                          |                |

## Weitere Ausgabe-Methoden

Die Methode 'outJavaScript()' sollte am Ende des Dokuments aufgerufen werden. Sie gibt den im Renderer definierten
JavaScript-Code aus, der unter anderem notwendig ist, damit die Info-Buttons zum Anzeigen der Beschreibung eines Feldes
funktionieren.
```
<script type=\"text/javascript\">$('[data-toggle=\"popover\"]').popover();</script>
```
Die Methode 'outButtons()' gibt nur die Buttons aus, die bis zu dem Zeitpunkt des Aufrufs der Methode zu dem Formular 
hinzugefügt wurden.
<?php

/**
 * Created by PhpStorm.
 * User: alina
 * Date: 26.10.15
 * Time: 10:22
 */
namespace cform;

class CFormSimpleRenderer implements CFormRenderer {

    private $mToClose = [];

    /**
     * @param $action
     * @param $method
     * @param array $items
     * @return mixed
     */
    public function render($action, $method, array $items) {
        $form = "<form action=\"{$action}\" method=\"{$method}\">\n";
        array_push($this->mToClose, "</form>\n");
        return $form . $this->render_standalone($items) . array_pop($this->mToClose);
    }

    /**
     * @param array $items
     * @return mixed
     */
    public function render_standalone(array $items) {
        $form = '';
        foreach ($items as $item) {
            $tag = strtolower($item->tag);
            $text = $item->displayValue;

            if ($tag == "html") {
                $form .= $text;
                continue;
            }

            $label = "";
            if ($item->label != null) {
                $lab = $item->label;
                $label = "<label ";
                if (array_key_exists('id', $item->attributes)) {
                    $label .= "for=\"{$item->attributes['id']}\"";
                }
                $label .= " class=\"label\">{$lab}</label>\n";
            }

            $options = "";
            if (count($opts = $item->options) != 0) {
                foreach ($opts as $key => $value) {
                    if ($item->selected == $key) {
                        $options .= "<option value=\"{$key}\" selected=\"selected\">{$value}</option>\n";
                    } else {
                        $options .= "<option value=\"{$key}\">{$value}</option>\n";
                    }
                }
            }

            $infobtn = "";
            if ($item->discription != null) {
                $infobtn = "<a tabindex='0' role=\"button\" class=\"infobutton\" data-trigger='focus' data-html=\"true\" data-toggle=\"popover\" data-container=\"body\" data-content=\"{$item->discription}\"><span class=\"\"></span></a>";
            }

            $element = "<{$tag}";
            foreach ($item->attributes as $key => $value) {
                $element .= " {$key}=\"{$value}\"";
            }

            if ($tag == "button") {
                $container = "<div class=\"container\">\n";
                array_push($this->mToClose, "</div>\n");

                $element .= " class=\"btn\">";
                array_push($this->mToClose, "</{$tag}>\n");
            } elseif ($tag == "datalist") {
                $container = "<div class=\"container\">\n";
                array_push($this->mToClose, "</div>\n");

                $element .= ">";
                array_push($this->mToClose, "</{$tag}>\n");
            } elseif ($tag == "input") {
                $container = "<div class=\"container\">\n";
                array_push($this->mToClose, "</div>\n");

                $element .= " class=\"formElement\">";
                array_push($this->mToClose, "");
            } else {
                $container = "<div class=\"container\">\n";
                array_push($this->mToClose, "</div>\n");

                $element .= " class=\"formElement\">";
                array_push($this->mToClose, "</{$tag}>\n");
            }
            $form .= $container . $label . $element . $options . $text . array_pop($this->mToClose) . $infobtn . array_pop($this->mToClose);
        }
        return $form;
    }

    /**
     * @return mixed
     */
    public function render_js() {
        $ret = "<script type=\"text/javascript\">$('[data-toggle=\"popover\"]').popover();</script>";
        return $ret;
    }
}<?php

/**
 * Created by PhpStorm.
 * User: alina
 * Date: 02.10.15
 * Time: 14:34
 */
namespace cform;

class CFormElement {

    private $tag;
    private $displayValue;
    private $attributes = [];
    private $label;
    private $discription;
    private $options = [];
    private $selected;

    /**
     * @return mixed
     */
    public function getSelected() {
        return $this->selected;
    }

    /**
     * @param mixed $selected
     */
    public function setSelected($selected) {
        $this->selected = $selected;
    }

    /**
     * @return mixed
     */
    public function getTag() {
        return $this->tag;
    }

    /**
     * @param mixed $tag
     */
    public function setTag($tag) {
        $this->tag = $tag;
    }

    /**
     * @return mixed
     */
    public function getDiscription() {
        return $this->discription;
    }

    /**
     * @param mixed $discription
     */
    public function setDiscription($discription) {
        $this->discription = $discription;
    }

    /**
     * @return null
     */
    public function getDisplayValue() {
        return $this->displayValue;
    }

    /**
     * @param null $displayValue
     */
    public function setDisplayValue($displayValue) {
        $this->displayValue = $displayValue;
    }

    /**
     * @return array
     */
    public function getAttributes() {
        return $this->attributes;
    }

    /**
     * @param array $attributes
     */
    public function setAttributes(array $attributes) {
        $this->attributes = $attributes;
    }

    /**
     * @return mixed
     */
    public function getLabel() {
        return $this->label;
    }

    /**
     * @param mixed $label
     */
    public function setLabel($label) {
        $this->label = $label;
    }

    /**
     * @return array
     */
    public function getOptions() {
        return $this->options;
    }

    /**
     * @param array $options
     */
    public function setOptions(array $options) {
        $this->options = $options;
    }

    public function __get($name) {
        return $this->$name;
    }

    /**
     * @param $key
     * @param $val
     */
    public function setAttribute($key, $val) {
        $key = strtolower($key);
        if (!is_array($val)) {
            $val = htmlspecialchars($val);
        }
        if (substr($key, 0, 1) == "@") {
            $key = substr($key, 1, strlen($key));
            if ($key == "label") {
                $this->label = $val;
            }
        } elseif ($key == "options" || is_array($val)) {
            foreach ($val as $_key => $_value) {
                $this->options[$_key] = $_value;
            }
        } elseif ($key == "displayvalue") {
            $this->displayValue = $val;
        } else {
            if ($key == "value") {
                $this->selected = $val;
            }
            $this->attributes[$key] = $val;
        }
    }

    /**
     * @param $tag
     * @param array $items
     * @param null $displayVal
     */
    public function __construct($tag, array $items = null, $displayVal = null) {
        $this->tag = $tag;
        if ($tag != "html") {
            $this->displayValue = htmlspecialchars($displayVal);
        }
        if ($items != null) {
            foreach ($items as $key => $value) {
                $this->setAttribute($key, $value);
            }
        }
    }

}
<?php

/**
 * Created by PhpStorm.
 * User: alina
 * Date: 02.10.15
 * Time: 14:34
 */
namespace cform;

class CForm {

    /**
     * @var CFormRenderer
     */
    protected $mRenderer;

    /**
     * @var string
     */
    protected $mAction;

    /**
     * @var  string
     */
    protected $mMethod;

    /**
     * @var array CFormElement
     */
    protected $mItems;

    /**
     * @var CFormElement
     */
    protected $mCurElement;


    /**
     * @param CFormRenderer $renderer
     */
    public function __construct(CFormRenderer $renderer) {
        $this->mRenderer = $renderer;
    }


    /**
     * @param $action
     * @return $this
     */
    public function setAction($action) {
        $this->mAction = $action;
        return $this;
    }

    /**
     * @param $method
     * @return $this
     * @throws \Exception
     */
    public function setMethod($method) {
        $method = strtoupper($method);
        if ($method == "POST" || $method == "GET") {
            $this->mMethod = $method;
        } else {
            throw new \Exception ("Invalid method committed");
        }
        return $this;
    }


    /**
     * @param $file
     * @return $this
     */
    public function loadFromFile($file) {
        $arr = require $file;
        foreach ($arr as $item) {
            $tag = $item[0];
            unset( $item[0] );
            $this->mItems[] = new CFormElement($tag, $item);
        }
        return $this;
    }


    /**
     * @param $tag
     * @param array $vals
     * @param null $displayVal
     * @return $this
     */
    public function addItem($tag, array $vals = null, $displayVal = null) {
        $this->mCurElement = new CFormElement($tag, $vals, $displayVal);
        $this->mItems[] = $this->mCurElement;
        return $this;
    }

    /**
     * @param array|null $vals
     * @return $this
     */
    public function addInput(array $vals = null) {
        $this->addItem("input", $vals);
        return $this;
    }

    /**
     * @param array|null $vals
     * @return $this
     */
    public function addSelect(array $vals = null) {
        $this->addItem("select", $vals);
        return $this;
    }

    /**
     * @param array|null $vals
     * @param null $displayVal
     * @return $this
     */
    public function addTextarea(array $vals = null, $displayVal = null) {
        $this->addItem("textarea", $vals, $displayVal);
        return $this;
    }

    /**
     * @param array|null $vals
     * @param null $displayVal
     * @return $this
     */
    public function addButton(array $vals = null, $displayVal = null) {
        $this->addItem("button", $vals, $displayVal);
        return $this;
    }

    /**
     * @param array|null $vals
     * @param null $displayVal
     * @return $this
     */
    public function addOutput(array $vals = null, $displayVal = null) {
        $this->addItem("output", $vals, $displayVal);
        return $this;
    }


    public function addDiscription($text) {
        $this->mCurElement->setDiscription(htmlspecialchars($text));
        return $this;
    }


    /**
     * @param $value
     * @param $display
     * @return $this
     * @throws Exception
     */
    public function addOption($value, $display) {
        if ($this->mCurElement == null) {
            throw new Exception("No current element available.");
        }
        $arr = $this->mCurElement->getOptions();
        $arr[$value] = $display;
        $this->mCurElement->setOptions($arr);
        return $this;
    }

    /**
     * @param array $opts
     * @return $this
     * @throws Exception
     */
    public function addOptions(array $opts) {
        foreach ($opts as $k => $v) {
            $this->addOption($k, $v);
        }
        return $this;
    }


    /**
     * Inserts HTML code between form-elements
     *
     * @param $code
     * @return $this
     */
    public function addHTMLCode($code) {
        $this->addItem("html", [], $code);
        return $this;
    }


    /**
     * Adds a label-element in front of HTML element
     *
     * @param $value
     * @return $this
     * @throws Exception
     */
    public function setLabel($value) {
        if ($this->mCurElement == null) {
            throw new Exception("No current element available.");
        }
        $this->mCurElement->setAttribute("@label", $value);
        return $this;
    }


    /**
     * Adds an attribute to the HTML element
     *
     * @param $name
     * @param $val
     * @return $this
     * @throws Exception
     */
    public function setAttr($name, $val) {
        if ($this->mCurElement == null) {
            throw new Exception("No current element available.");
        }
        $this->mCurElement->setAttribute($name, $val);
        return $this;
    }


    /**
     * @param $id
     * @return $this
     * @throws Exception
     */
    public function setId($id) {
        $this->setAttr("id", $id);
        return $this;
    }

    /**
     * @param $name
     * @return $this
     * @throws Exception
     */
    public function setName($name) {
        $this->setAttr("name", $name);
        return $this;
    }

    /**
     * @param $type
     * @return $this
     * @throws Exception
     */
    public function setType($type) {
        $this->setAttr("type", $type);
        return $this;
    }

    /**
     * @param $value
     * @return $this
     * @throws Exception
     */
    public function setValue($value) {
        $this->setAttr("value", $value);
        return $this;
    }


    /**
     * Resets the list of form elements
     */
    private function reset() {
        $this->mCurElement = null;
        $this->mItems = [];
    }


    /**
     * Prints form
     */
    public function out() {
        echo $this->mRenderer->render($this->mAction, $this->mMethod, $this->mItems);
        $this->reset();
    }

    /**
     * Prints all form elements in list without surrounding <form> tags
     * Resets all elements in list
     */
    public function outPart(array $ids = null) {
        if ($ids == null) {
            echo $this->mRenderer->render_standalone($this->mItems);
            $this->reset();
        } else {
            $items = [];
            foreach ($this->mItems as $item) {
                $attrs = $item->getAttributes();
                if (array_key_exists("id", $attrs) && in_array($attrs['id'], $ids)) {
                    $items [] = $item;
                }
            }
            echo $this->mRenderer->render_standalone($items);
        }
    }

    public function outButtons() {
        $items = [];
        foreach ($this->mItems as $item) {
            if ($item->getTag() == "button") {
                $items[] = $item;
            }
        }
        echo $this->mRenderer->render_standalone($items);
    }

    public function outJavaScript() {
        echo $this->mRenderer->render_js();
    }

}
<?php

/**
 * Created by PhpStorm.
 * User: alina
 * Date: 05.10.15
 * Time: 09:30
 */
namespace cform;

interface CFormRenderer {

    /**
     * @param $action
     * @param $method
     * @param array $items
     * @return mixed
     */
    public function render($action, $method, array $items);

    /**
     * @param array $items
     * @return mixed
     */
    public function render_standalone(array $items);

    /**
     * @return mixed
     */
    public function render_js();

}<?php

/**
 * Created by PhpStorm.
 * User: alina
 * Date: 05.10.15
 * Time: 09:29
 */
namespace cform;

class CFormBootstrapRenderer implements CFormRenderer {

    private $mToClose = [];

    /**
     * @param $action
     * @param $method
     * @param array $items
     * @return string
     */
    public function render($action, $method, array $items) {
        $form = "<form class=\"form-horizontal\" action=\"{$action}\" method=\"{$method}\">\n";
        array_push($this->mToClose, "</form>\n");
        return $form . $this->render_standalone($items) . array_pop($this->mToClose);
    }

    /**
     * @return string
     */
    public function render_js() {
        $ret = "<script type=\"text/javascript\">$('[data-toggle=\"popover\"]').popover();</script>";
        return $ret;
    }

    /**
     * @param array $items
     * @return string
     */
    public function render_standalone(array $items) {
        $form = "";
        foreach ($items as $item) {
            $tag = strtolower($item->tag);
            $text = $item->displayValue;

            if ($tag == "html") {
                $form .= $text;
                continue;
            }

            $label = "";
            if ($item->label != null) {
                $lab = $item->label;
                $label = "<label ";
                if (array_key_exists('id', $item->attributes)) {
                    $label .= "for=\"{$item->attributes['id']}\"";
                }
                $label .= " class=\"control-label col-md-3\">{$lab}</label>\n";
            }

            $options = "";
            if (count($opts = $item->options) != 0) {
                foreach ($opts as $key => $value) {
                    if ($item->selected == $key) {
                        $options .= "<option value=\"{$key}\" selected=\"selected\">{$value}</option>\n";
                    } else {
                        $options .= "<option value=\"{$key}\">{$value}</option>\n";
                    }
                }
            }

            $infobtn = "";
            if ($item->discription != null) {
                $infobtn = "<a tabindex='0' role=\"button\" class=\"btn btn-default\" data-trigger='focus' data-html=\"true\" data-toggle=\"popover\" data-container=\"body\" data-content=\"{$item->discription}\"><span class=\"glyphicon glyphicon-info-sign\"></span></a>";
            }

            $element = "<{$tag}";
            foreach ($item->attributes as $key => $value) {
                $element .= " {$key}=\"{$value}\"";
            }

            if ($tag == "button") {
                $container = "<div class=\"navbar\">\n<div class=\"container-fluid\">\n";
                array_push($this->mToClose, "</div>\n</div>\n");

                $elemcon = "<div class=\"navbar-form navbar-right\">\n";
                array_push($this->mToClose, "</div>\n");

                $element .= " class=\"btn btn-success pull-right\">";
                array_push($this->mToClose, "</{$tag}>\n");
            } elseif ($tag == "datalist") {
                $container = "<div class=\"form-group\">\n";
                array_push($this->mToClose, "</div>\n");

                $elemcon = "<div class=\"col-md-8\">\n";
                array_push($this->mToClose, "</div>\n");

                $element .= ">";
                array_push($this->mToClose, "</{$tag}>\n");
            } elseif ($tag == "input") {
                $container = "<div class=\"form-group\">\n";
                array_push($this->mToClose, "</div>\n");

                $elemcon = "<div class=\"col-md-8\">\n";
                array_push($this->mToClose, "</div>\n");

                $element .= " class=\"form-control\">";
                array_push($this->mToClose, "");
            } else {
                $container = "<div class=\"form-group\">\n";
                array_push($this->mToClose, "</div>\n");

                $elemcon = "<div class=\"col-md-8\">\n";
                array_push($this->mToClose, "</div>\n");

                $element .= " class=\"form-control\">";
                array_push($this->mToClose, "</{$tag}>\n");
            }

            $form .= $container . $label . $elemcon . $element . $options . $text . array_pop($this->mToClose) . array_pop($this->mToClose) . $infobtn . array_pop($this->mToClose);
        }
        return $form;
    }
}
׮Y�/J��Z_��8�N�z   GBMB